import React, { useState } from 'react';
import axios from 'axios';

const App = () => {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);

  const fetchWeather = async () => {
    if (!city) return;
    try {
      const res = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${import.meta.env.VITE_WEATHER_API_KEY}&units=metric`
      );
      setWeather(res.data);
    } catch (err) {
      alert('City not found');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center">
      <h2 className="text-3xl font-bold mb-8">React Weather App 🌤️</h2>
      <div className="mb-4">
        <input
          className='h-10 border-gray-300 border rounded-2xl mr-10 pl-4 mt-4 '
          type="text"
          placeholder="Enter City Name"
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <button
          className="bg-gray-400 border border-amber-400 rounded-2xl px-4 h-10 text-white"
          onClick={fetchWeather}
        >
          Search
        </button>
      </div>

      {weather && (
        <div className="bg-white rounded-xl shadow-md p-6 mt-6 w-64 text-center">
          <h2 className="text-xl font-bold">{weather.name}, {weather.sys.country}</h2>
          <p className="capitalize">{weather.weather[0].description}</p>
          <p>🌡️ {weather.main.temp}°C</p>
          <p>💧 Humidity: {weather.main.humidity}%</p>
          <p>💨 Wind: {weather.wind.speed} m/s</p>
          <img
            className="mx-auto mt-2"
            src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
            alt="Weather Icon"
          />
        </div>
      )}
    </div>
  );
};

export default App;
